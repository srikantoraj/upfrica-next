// import Footer from '@/components/common/footer/Footer';
// import Header from '@/components/common/header/Header';
// import ProductList from '@/components/home/ProductList/ProductList';
// import RelatedProducts from '@/components/home/ProductList/RealtedProduct';
// import ProductDetailSection from '@/components/ProductDetailSection/ProductDetailSection';
// import Slider from '@/components/Slider';
// import TextSection from '@/components/TextSection';
// import Dummy from '@/components/ui/details/Dummy';
// import React from 'react';

// // Update getProductData to accept a string slug directly
// async function getProductData(slug) {
//     if (!slug) {
//         // You might want to handle this case differently in a server component.
//         throw new Error('No product selected');
//     }
//     const res = await fetch(`https://media.upfrica.com/api/products/${slug}/`, {
//         cache: 'no-store', // Use 'no-store' if data changes frequently
//     });

//     if (!res.ok) {
//         // Handle errors gracefully
//         throw new Error('Failed to fetch product data');
//     }

//     return res.json();
// }

// // Generate dynamic metadata for each product page
// export async function generateMetadata({ params }) {
//     // params.slug is an array; extract the first segment or join if necessary.
//     const slugArray = params.slug || [];
//     const slug = slugArray[0]; // or use: const slug = slugArray.join('/');

//     const product = await getProductData(slug);

//     // Example of cleaning description text
//     function removeSpecificTags(input) {
//         if (typeof input !== 'string') {
//             throw new TypeError('Input must be a string');
//         }
//         const regex = /<\/?(li|ul|p)[^>]*>/gi;
//         return input.replace(regex, '');
//     }

//     return {
//         title: `${product.title} - ${product?.user?.country}`,
//         description: product?.description?.body,
//         // Additional metadata can be added here.
//     };
// }

// // The main component to render product details
// export default async function ProductDetails({ params }) {
//     // Extract the slug from the params. Since this is a catch-all route, it's an array.
//     const slugArray = params.slug || [];
//     const slug = slugArray[0]; // or use: const slug = slugArray.join('/');

//     // Fetch the product data using the slug
//     const product = await getProductData(slug);

//     return (
//         <>
//             <Header />
//             <div className="container mx-auto">
//                 <ProductDetailSection product={product} />
//                 <RelatedProducts productId={slug} />
//             </div>
//             <Footer />
//         </>
//     );
// }


import Footer from '@/components/common/footer/Footer';
import Header from '@/components/common/header/Header';
import ProductList from '@/components/home/ProductList/ProductList';
import RelatedProducts from '@/components/home/ProductList/RealtedProduct';
import ProductDetailSection from '@/components/ProductDetailSection/ProductDetailSection';
import Slider from '@/components/Slider';
import TextSection from '@/components/TextSection';
import Dummy from '@/components/ui/details/Dummy';
import React from 'react';

// Update getProductData to accept a string slug directly
async function getProductData(slug) {
    if (!slug) {
        throw new Error('No product selected');
    }
    const res = await fetch(`https://media.upfrica.com/api/products/${slug}/`, {
        cache: 'no-store',
    });

    if (!res.ok) {
        throw new Error('Failed to fetch product data');
    }

    return res.json();
}

// Generate dynamic metadata for each product page
export async function generateMetadata({ params }) {
    // params.slug is an array; get the last segment (the actual product slug)
    const slugArray = params.slug || [];
    const slug = slugArray[slugArray.length - 1];

    const product = await getProductData(slug);

    // Example of cleaning description text (if needed)
    function removeSpecificTags(input) {
        if (typeof input !== 'string') {
            throw new TypeError('Input must be a string');
        }
        const regex = /<\/?(li|ul|p)[^>]*>/gi;
        return input.replace(regex, '');
    }

    return {
        title: `${product.title} - ${product?.user?.country}`,
        description: product?.description?.body,
    };
}

// The main component to render product details
export default async function ProductDetails({ params }) {
    // Extract the slug from the params. Use the last element of the catch-all array.
    const slugArray = params.slug || [];
    const slug = slugArray[slugArray.length - 1];

    // Fetch the product data using the slug
    const product = await getProductData(slug);

    return (
        <>
            <Header />
            <div className="container mx-auto">
                <ProductDetailSection product={product} />
                <RelatedProducts productId={slug} />
            </div>
            <Footer />
        </>
    );
}
